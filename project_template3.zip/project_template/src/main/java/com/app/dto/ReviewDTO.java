package com.app.dto;

import com.app.entities.Doctor;
import com.app.entities.User;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;



@Getter
@Setter
@ToString
public class ReviewDTO {
	
	//private Doctor rdoctorId;
	
	//private User ruserId;
	
	private Long doctorId;
	private Long userId;
	
	private double rating;
	
	private String review;
}
