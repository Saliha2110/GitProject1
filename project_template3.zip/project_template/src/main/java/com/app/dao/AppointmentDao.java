//package com.app.dao;
//
//import java.util.List;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import com.app.entities.Appointment;
//import com.app.entities.Doctor;
//import com.app.entities.User;
//
//public interface AppointmentDao extends JpaRepository<Appointment, Long>{
//	
//	
//	List<Appointment> findByUser(User user);
//	
//	List<Appointment> findByDoctor(Doctor doctor);
//}
