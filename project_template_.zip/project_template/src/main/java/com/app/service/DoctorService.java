package com.app.service;

import java.util.List;

import com.app.dto.ResponseText;
import com.app.dto.SignUpDoctor;
import com.app.entities.Doctor;

public interface DoctorService {
	ResponseText addDcotor(SignUpDoctor doc);
	
	List<SignUpDoctor> displayDoctors();
	
	List<SignUpDoctor> displayDoctorsByDeptId(Long dept_id);
}
