package com.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.AppointmentDao;

@Service
@Transactional
public class AppointmentServiceImpl implements AppointmentService {

		public AppointmentServiceImpl() {
			System.out.println("in ctor of " + getClass());
		}
		
		@Autowired
		private AppointmentDao appDao;
}
