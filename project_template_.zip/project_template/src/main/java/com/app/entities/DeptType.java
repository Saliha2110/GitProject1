package com.app.entities;

public enum DeptType {
			GENERAL_MEDICINE , CARDIOLOGY , DENTISTRY , ENT , ORTHOPEDIC , DERMATOLOGY 
}
