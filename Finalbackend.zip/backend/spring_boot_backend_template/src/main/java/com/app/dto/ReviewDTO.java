package com.app.dto;

import com.app.entities.Doctor;
import com.app.entities.User;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;



@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ReviewDTO {
	
	//private Doctor rdoctorId;
	
	//private User ruserId;
	
	private Long doctorId;
	private Long userId;
	
	private double rating;
	
	private String review;
}
