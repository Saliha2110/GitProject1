package com.app.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.custom_exceptions.ResourceNotFoundException;
import com.app.dao.UserDao;
import com.app.dto.AuthRequest;
import com.app.dto.AuthResp;
import com.app.dto.EditPassDTO;
import com.app.dto.OTPVerificationDTO;
import com.app.dto.SignUpDetails;
import com.app.dto.SignupRequest;
import com.app.dto.SignupResponse;
import com.app.dto.UpdateRequest;
import com.app.entities.User;

@Service
@Transactional
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao userDao;

	@Autowired
	private ModelMapper mapper;

	
	@Autowired
	private JavaMailSender javaMailSender;

	
	@Override
	public AuthResp singInUser(AuthRequest request) {
	
		User user = userDao.findByEmailAndPassword(request.getEmail(), request.getPassword())
				.orElseThrow(() -> new ResourceNotFoundException("Invalid Email or Password !!!!"));
		// => signin success , emp : persistent
		// ModelMapper API
		// public DestType map(Object src ,Class<DestType> cls)
		return mapper.map(user, AuthResp.class);
		
		
	}


	@Override
	public AuthResp getUserDetails(Long userId) {
		// TODO Auto-generated method stub
		User user=userDao.findById(userId).orElseThrow(() -> new ResourceNotFoundException("Invalid User ID !!!!!"));
		AuthResp resp=mapper.map(user, AuthResp.class);
		
		return  resp;
	}


	@Override
	public List<AuthResp> getAllUsers() {
		List<User> users=userDao.findAll();
		List<AuthResp> list=new ArrayList<AuthResp>();
		
		for(User u:users) {
			AuthResp user = mapper.map(u, AuthResp.class);
		list.add(user);
		}
		return list;
	}


	@Override
	public SignupResponse addUserDetails(SignupRequest newUser) {
		// TODO Auto-generated method stub
		
		System.out.println("request "+newUser);
		
		User persitentUser=userDao.save(mapper.map(newUser, User.class));
		
		return mapper.map(persitentUser, SignupResponse.class);
	}


	@Override
	public String deleteUserDetails(Long userId) {
		
		User foundEmp = userDao.findById(userId)
				.orElseThrow(() -> new ResourceNotFoundException("Invalid User ID !!!!!"));
		// emp exists !, foundEmp : persistent
		userDao.deleteById(userId);
		return "User details deleted successfully!";
	}


//	@Override
//	public SignupResponse updateUserDetails(UpdateRequest updatedUser) {
//		
//		
//		User foundUser = userDao.findById(updatedUser.getUserId())
//				.orElseThrow(() -> new ResourceNotFoundException("Invalid User ID !!!!!"));
//		//foundUser.getAppmnt().size();
////		foundUser.getAppmnt()
//		// emp exists !, foundEmp : persistent
//		
//			User user = mapper.map(updatedUser, User.class);
//			user.setPassword(foundUser.getPassword());
//			//user.setAppmnt(foundUser.getAppmnt());
//		
//		userDao.save(user);
//		
//		return mapper.map(user, SignupResponse.class);
//		
//		
//	}
	@Override
	public SignupResponse updateUserDetails(UpdateRequest updatedUser) {
		
		
		User foundUser = userDao.findById(updatedUser.getUserId())
				.orElseThrow(() -> new ResourceNotFoundException("Invalid User ID !!!!!"));
		
			
			foundUser.setMobile(updatedUser.getMobile());
			foundUser.setFirstName(updatedUser.getFirstName());
			foundUser.setLastName(updatedUser.getLastName());
		
		
		userDao.save(foundUser);
		
		return mapper.map(foundUser, SignupResponse.class);
		
		
	}
	

	//-------------------------------------------------------------------
		//-------------------------------------------------------------------
		

	SignupRequest userObj=new SignupRequest();

	private Map<String, String> otpMap = new HashMap<>();

	//SignUpRequest userObj = new SignUpRequest();

		public void sendOTPAndStoreUserData(SignupRequest userRegistrationDTO) {
			userObj = userRegistrationDTO;
			String otp = generateOTP();
			sendOTPEmail(userRegistrationDTO.getEmail(), otp);
			otpMap.put(userRegistrationDTO.getEmail(), otp);
		}

		@Override
		public boolean verifyOTP(OTPVerificationDTO otpVerificationDTO) {
			String storedOTP = otpMap.get(userObj.getEmail());
			otpMap=null;
			return storedOTP != null && storedOTP.equals(otpVerificationDTO.getOtp());
		}


	private String generateOTP() {
			int otpLength = 6;
			String numbers = "0123456789";
			StringBuilder otp = new StringBuilder();

			for (int i = 0; i < otpLength; i++) {
				int index = (int) (Math.random() * numbers.length());
				otp.append(numbers.charAt(index));
			}

			return otp.toString();
		}





	private void sendOTPEmail(String email, String otp) {
			MimeMessage message = javaMailSender.createMimeMessage();

			try {
				MimeMessageHelper helper = new MimeMessageHelper(message, true);
				helper.setTo(email);
				helper.setSubject("OTP Verification");
				helper.setText("Your OTP for registration is: " + otp);
				javaMailSender.send(message);
			} catch (MessagingException e) {
				// Handle exception
				System.out.println("in the send otp");
			}
		}
		
		
		
		SignUpDetails cust =new SignUpDetails();
		
	 
		
	//-----------------------------------------	
//		@Override
//		public void getOtpForForgotPass(String emailId) {
//			 cust=userDao.findByEmail(emailId);
//			 userObj.setEmail(emailId);
//			if(cust.getEmail()!=null)
//			{
//				String otp = generateOTP();
//				sendOTPEmail(emailId, otp);
//				otpMap.put(emailId, otp);
//			}
//			else if(cust.getEmail()==null)
//				throw new ResourceNotFoundException("User Does not exist from userServiceImpl Class");	
//			
//		}
	//----------------------------------------------------	
		
		@Override
		public void getOtpForForgotPass(String emailId) {
			 User user=userDao.findByEmail(emailId);
			 userObj.setEmail(emailId);
			if(user.getEmail()!=null)
			{
				String otp = generateOTP();
				sendOTPEmail(emailId, otp);
				otpMap.put(emailId, otp);
			}
			else if(user.getEmail()==null)
				throw new ResourceNotFoundException("User Does not exist from userServiceImpl Class");	
			
		}
		
		
		
//		@Override
//		public SignupResponse storeUserDataWithNewPass(EditPassDTO newPass) {
//			
//			cust.setPassword(newPass.getNewPassword());
//			SignUpDetails persistentUser = userDao.save(cust);
	//
//			return mapper.map(persistentUser, SignupResponse.class);
//					
//		}
		
		
//		@Override
//		public SignupResponse storeUserDataWithNewPass(EditPassDTO newPass) {
//		    SignUpDetails cust = userDao.findByEmail(userObj.getEmail()); // Fetch user details based on email
//		    if (cust != null) {
//		        cust.setPassword(newPass.getNewPassword()); // Update the password
//		        SignUpDetails persistentUser = userDao.save(cust); // Save the updated user details
	//
//		        return mapper.map(persistentUser, SignupResponse.class); // Map to response object
//		    } else {
//		        throw new ResourceNotFoundException("User Does not exist from userServiceImpl Class");
//		    }
//		}
		
		
		@Override
		public SignupResponse storeUserDataWithNewPass(EditPassDTO newPass) {
		    User user = userDao.findByEmail(userObj.getEmail()); // Fetch user details based on email
		    if (user != null) {
		        user.setPassword(newPass.getNewPassword()); // Update the password
		        User persistentUser = userDao.save(user); // Save the updated user details

		        return mapper.map(persistentUser, SignupResponse.class); // Map to response object
		    } else {
		        throw new ResourceNotFoundException("User Does not exist from userServiceImpl Class");
		    }
		}
	
	
	
}
