package com.app.service;

import java.util.List;

import com.app.dto.DisplayReview;
import com.app.dto.ResponseText;
import com.app.dto.ReviewDTO;
import com.app.entities.Review;

public interface ReviewService {

	
public ResponseText addNewReview(ReviewDTO review);



	public List<DisplayReview> getReviewById(Long doctorId);
	
	public 	Double getAvgDoctorRatingById(Long doctorId);
	
	//public Double getAvgProductRatingById(Long id);
	
//	public List<AvgRatingResponseDTO> getAvgProductRatingOfAllProducts();
}
