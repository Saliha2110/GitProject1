package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.AppointmentDto;
import com.app.dto.ResponseText;
import com.app.service.AppointmentService;

@RestController
@RequestMapping("/appointmemts")
public class AppointmentController {
	
	
	public AppointmentController() {
		System.out.println("in appointment controller ");
	}
	
	@Autowired
	private AppointmentService appService; 
	
	@PostMapping
	public ResponseEntity<?> bookAppointment(@RequestBody AppointmentDto appDto){
		System.out.println("in book appointmemt method of" + getClass());
		appService.bookAppointment(appDto);
		return ResponseEntity.ok(new ResponseText("Appointment booked successfully"));
	}
}
