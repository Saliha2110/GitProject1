package com.app.service;

import com.app.dto.AppointmentDto;
import com.app.dto.ResponseText;

public interface AppointmentService {
		public ResponseText bookAppointment(AppointmentDto appointDto);
}
