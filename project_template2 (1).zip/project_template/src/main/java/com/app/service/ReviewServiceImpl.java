package com.app.service;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.custom_exceptions.ResourceNotFoundException;
import com.app.dao.DoctorDao;
import com.app.dao.ReviewDao;
import com.app.dao.UserDao;
import com.app.dto.ReviewDTO;
import com.app.entities.Doctor;
import com.app.entities.Review;
import com.app.entities.User;

@Service
@Transactional
public class ReviewServiceImpl implements ReviewService {

	@Autowired
	private ReviewDao dao;
	
	@Autowired
	private ModelMapper mapper;
	
	@Autowired
	private UserDao userDao; //we have used this bcz we have to find user as a patient and set it into appointment
	
	//similarly to doctor which is user
	@Autowired
	private DoctorDao docDao;
	

	
	
//	@Override
//	public Review addNewReview(ReviewDTO review) {
//		
//		Review newReview = mapper.map(review, Review.class);
//		Product product = productService.getProductById(review.getProduct_id()).orElseThrow();
//		User customer = customerService.getCustomerById(review.getCustomer_id());
//		newReview.setProduct(product);
//		newReview.setCustomer(customer);
//		return dao.save(newReview);
//	}
	
//	@Override
//	public Review addNewReview(ReviewDTO review) {
//		
//		
//		
//		User userPatient = userDao.findById(review.getUserId())
//				.orElseThrow(() -> new ResourceNotFoundException("Invalid Dept ID !!!!!"));
//		
//		Doctor userDoctor = docDao.findById(review.getDoctorId())
//				.orElseThrow(() -> new ResourceNotFoundException("Invalid Dept ID !!!!!"));
//		
//		Review newReview =new Review();
//		
//		newReview.setRuserId(userPatient);
//		newReview.setRdoctorId(userDoctor);
//		
//		mapper.map(review, Review.class);
//		return dao.save(newReview);
//		
//		
//	}
	
	
	@Override
	public Review addNewReview(ReviewDTO review) {
	    User userPatient = userDao.findById(review.getUserId())
	            .orElseThrow(() -> new ResourceNotFoundException("Invalid User ID for Patient!"));

	    Doctor userDoctor = docDao.findById(review.getDoctorId())
	            .orElseThrow(() -> new ResourceNotFoundException("Invalid Doctor ID!"));

	    Review newReview = new Review();
	    newReview.setRuserId(userPatient);
	    newReview.setRdoctorId(userDoctor);
	    newReview.setRating(review.getRating());
	    newReview.setReview(review.getReview());

	    return dao.save(newReview);
	}
	
	
	
//	@Override
//	public List<Review> getReviewById(Long id) {
//		
//		
//		
//		Doctor userDoctor = docDao.findById(id)
//				.orElseThrow(() -> new ResourceNotFoundException("Invalid Dept ID !!!!!"));
//		
//		
//		 return dao.findByRdoctorId(userDoctor);
//	}
	
	
	
	@Override
    public List<Review> getReviewById(Long id) {
        Doctor doctor = docDao.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Invalid Doctor ID !!!!!"));

        return dao.findByRdoctorId(doctor);
    }

	@Override
    public Double getAvgDoctorRatingById(Long doctorId) {
        return dao.getAvgDoctorRatingById(doctorId);
    }
	

//	@Override
//	public Double getAvgProductRatingById(Long id) {
//		Product product = productService.getProductById(id).orElseThrow();
//		
//		return dao.getAvgRatingOfProductById(product.getId());
//	}

//	@Override
//	public List<AvgRatingResponseDTO> getAvgProductRatingOfAllProducts() {
//		return dao.getAvgRatingProductOfAllProducts();
//	}
	
}
