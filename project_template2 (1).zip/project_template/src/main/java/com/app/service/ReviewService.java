package com.app.service;

import java.util.List;

import com.app.dto.ReviewDTO;
import com.app.entities.Review;

public interface ReviewService {

	
public Review addNewReview(ReviewDTO review);



	public List<Review> getReviewById(Long id);
	
	public 	Double getAvgDoctorRatingById(Long doctorId);
	
	//public Double getAvgProductRatingById(Long id);
	
//	public List<AvgRatingResponseDTO> getAvgProductRatingOfAllProducts();
}
