package com.app.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.custom_exceptions.ResourceNotFoundException;
import com.app.dao.AppointmentDao;
import com.app.dao.DoctorDao;
import com.app.dao.UserDao;
import com.app.dto.AppointmentDto;
import com.app.dto.ResponseText;
import com.app.entities.Appointment;
import com.app.entities.Department;
import com.app.entities.Doctor;
import com.app.entities.User;

@Service
@Transactional
public class AppointmentServiceImpl implements AppointmentService {

		public AppointmentServiceImpl() {
			System.out.println("in ctor of " + getClass());
		}
		
		@Autowired
		private AppointmentDao appDao;
		
		@Autowired
		private UserDao userDao; //we have used this bcz we have to find user as a patient and set it into appointment
		
		//similarly to doctor which is user
		@Autowired
		private DoctorDao docDao;
		
		@Autowired
		private ModelMapper mapper;

		@Override
		public ResponseText bookAppointment(AppointmentDto appointDto) {
				
			User userPatient = userDao.findById(appointDto.getUserId())
					.orElseThrow(() -> new ResourceNotFoundException("Invalid Dept ID !!!!!"));
			
			Doctor userDoctor = docDao.findById(appointDto.getDoctorId())
					.orElseThrow(() -> new ResourceNotFoundException("Invalid Dept ID !!!!!"));
			
			Appointment appointment = new Appointment();
			appointment.setUsersId(userPatient);
			appointment.setDoctorsId(userDoctor);
			mapper.map(appointDto, Appointment.class);
			
			appDao.save(appointment);
			
				
			return null;
		}
}
